package com.company;

public interface superPouvoir {
    int extra = 2;
    /** possibilité de lancer un sort
     * @return intensité du sort */
    double sort();
}
