package com.company;

public interface Victime{
    int subitFrappe(int coup);
    int subitCharme(int coup);
}
